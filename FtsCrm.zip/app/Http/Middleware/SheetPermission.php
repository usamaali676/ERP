<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\perm;
use App\Models\Role;
use App\Models\Sales;
use Illuminate\Support\Facades\Route;
use RealRashid\SweetAlert\Facades\Alert;

class SheetPermission
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $routeName = Route::currentRouteName();
        $user = auth()->user();
        $role = Role::where('id', $user->role_id)->first();

        if($routeName == "sales") {
            $perms = perm::where('role_id', $role->id)->where('name', "Sales")->first();
            if($perms->view == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "sale-datail") {
            $perms = perm::where('role_id', $role->id)->where('name', "Sales")->first();
            if($perms->view == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "sale.create") {
            $perms = perm::where('role_id', $role->id)->where('name', "Sales")->first();
            if($perms->create == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "file-import") {
            $perms = perm::where('role_id', $role->id)->where('name', "Sales")->first();
            if($perms->create == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "sale.edit") {
            $perms = perm::where('role_id', $role->id)->where('name', "Sales")->first();
            if($perms->edit == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "sale.update") {
            $perms = perm::where('role_id', $role->id)->where('name', "Sales")->first();
            if($perms->update == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "sale.delete") {
            $perms = perm::where('role_id', $role->id)->where('name', "Sales")->first();
            if($perms->delete == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "sale.conf-delete") {
            $perms = perm::where('role_id', $role->id)->where('name', "Sales")->first();
            if($perms->delete == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        else{
            return $next($request);
        }
    }
}

