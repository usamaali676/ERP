<?php

namespace App\Http\Middleware;

use App\Models\perm;
use App\Models\Role;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Routing\Route;
use RealRashid\SweetAlert\Facades\Alert;

class DesignationPerm
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $routeName = Route::currentRouteName();
        $user = auth()->user();

        $role = Role::where('id', $user->role_id)->first();

        if($routeName == "desig.index") {
            $perms = perm::where('role_id', $role->id)->where('name', "Designation")->first();
            if($perms->view == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "desig.create") {
            $perms = perm::where('role_id', $role->id)->where('name', "Designation")->first();
            if($perms->create == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "desig.edit") {
            $perms = perm::where('role_id', $role->id)->where('name', "Designation")->first();
            if($perms->edit == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "desig.update") {
            $perms = perm::where('role_id', $role->id)->where('name', "Designation")->first();
            if($perms->update == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "desig.delete") {
            $perms = perm::where('role_id', $role->id)->where('name', "Designation")->first();
            if($perms->delete == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "desig.conf-delete") {
            $perms = perm::where('role_id', $role->id)->where('name', "Designation")->first();
            if($perms->delete == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        else{
            return $next($request);
        }
    }
}
