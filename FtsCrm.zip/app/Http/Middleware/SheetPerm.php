<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\PermissionRegistrar;
use Illuminate\Support\Facades\Gate;
use App\Models\User;
use RealRashid\SweetAlert\Facades\Alert;

class SheetPerm
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $user = auth()->user();
        $role = Role::findById($user->role_id);
        if( $role->hasPermissionTo('edit Sheet')){
            return $next($request);
        }
        Alert::error('Oops',"You Can't edit the Client");
        return redirect()->back();
    }
}
