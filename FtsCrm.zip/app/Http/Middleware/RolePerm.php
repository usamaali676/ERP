<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Models\Role;
use App\Models\perm;
use RealRashid\SweetAlert\Facades\Alert;

class RolePerm
{

    public function handle(Request $request, Closure $next)
    {
        $routeName = Route::currentRouteName();
        $user = auth()->user();
        // $role = Role::where('id', $user->id)->first();
        $role = $user->roles;
        // dd($role);
        // dd($routeName);
        if($routeName == "role.index") {
            $perms = perm::where('role_id', $role->id)->where('name', "Roles")->first();
            if($perms->view == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "role.detail") {
            $perms = perm::where('role_id', $role->id)->where('name', "Roles")->first();
            if($perms->view == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "role.create") {
            $perms = perm::where('role_id', $role->id)->where('name', "Roles")->first();
            if($perms->create == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "role.edit") {
            $perms = perm::where('role_id', $role->id)->where('name', "Roles")->first();
            if($perms->edit == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "role.update") {
            $perms = perm::where('role_id', $role->id)->where('name', "Roles")->first();
            if($perms->update == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "role.delete") {
            $perms = perm::where('role_id', $role->id)->where('name', "Roles")->first();
            if($perms->delete == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "role.conf-delete") {
            $perms = perm::where('role_id', $role->id)->where('name', "Roles")->first();
            if($perms->delete == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        else{
        return $next($request);
        }
    }
}
