<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Models\perm;
use App\Models\Role;
use RealRashid\SweetAlert\Facades\Alert;

class DepartmentPerm
{
   public function handle(Request $request, Closure $next)
    {
        $routeName = Route::currentRouteName();
        $user = auth()->user();

        $role = Role::where('id', $user->role_id)->first();

        if($routeName == "dept.index") {
            $perms = perm::where('role_id', $role->id)->where('name', "Department")->first();
            if($perms->view == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "dept.create") {
            $perms = perm::where('role_id', $role->id)->where('name', "Department")->first();
            if($perms->create == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "dept.edit") {
            $perms = perm::where('role_id', $role->id)->where('name', "Department")->first();
            if($perms->edit == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "dept.update") {
            $perms = perm::where('role_id', $role->id)->where('name', "Department")->first();
            if($perms->update == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "dept.delete") {
            $perms = perm::where('role_id', $role->id)->where('name', "Department")->first();
            if($perms->delete == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "dept.conf-delete") {
            $perms = perm::where('role_id', $role->id)->where('name', "Department")->first();
            if($perms->delete == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        else{
            return $next($request);
        }
    }
}
