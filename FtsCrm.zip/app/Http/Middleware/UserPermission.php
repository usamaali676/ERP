<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\perm;
use App\Models\Role;
use Illuminate\Support\Facades\Route;
use RealRashid\SweetAlert\Facades\Alert;
// use App\Models\Permission;


class UserPermission
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $routeName = Route::currentRouteName();
        $user = auth()->user();
        $role = Role::where('id', $user->role_id)->first();

        if($routeName == "user.index") {
            $perms = perm::where('role_id', $role->id)->where('name', "Users")->first();
            if($perms->view == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "user.detail") {
            $perms = perm::where('role_id', $role->id)->where('name', "Users")->first();
            if($perms->view == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "user.create") {
            $perms = perm::where('role_id', $role->id)->where('name', "Users")->first();
            if($perms->create == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "user.edit") {
            $perms = perm::where('role_id', $role->id)->where('name', "Users")->first();
            if($perms->edit == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "user.update") {
            $perms = perm::where('role_id', $role->id)->where('name', "Users")->first();
            if($perms->update == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "user.delete") {
            $perms = perm::where('role_id', $role->id)->where('name', "Users")->first();
            if($perms->delete == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        if($routeName == "user.conf-delete") {
            $perms = perm::where('role_id', $role->id)->where('name', "Users")->first();
            if($perms->delete == 1) {
               return $next($request);
            }
            else {
                Alert::error('Opps',"You can't Perfome this Opration");
                return redirect()->route('home');
            }
        }
        else{
            return $next($request);
        }
    }
}
