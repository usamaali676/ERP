        <!-- BEGIN: Mobile Menu -->
        <div class="mobile-menu md:hidden">
            <div class="mobile-menu-bar">
                <a href="" class="flex mr-auto">
                    <img alt="Firm TechSol" class="w-6" src="<?php echo e(asset('images/logo.svg')); ?>">
                </a>
                <a href="javascript:;" class="mobile-menu-toggler"> <i data-lucide="bar-chart-2" class="w-8 h-8 text-white transform -rotate-90"></i> </a>
            </div>
            <div class="scrollable">
                <a href="javascript:;" class="mobile-menu-toggler"> <i data-lucide="x-circle" class="w-8 h-8 text-white transform -rotate-90"></i> </a>
                <ul class="scrollable__content py-2">
                    <li>
                        <a href="javascript:;" class="menu">
                            <div class="menu__icon"> <i data-lucide="trello"></i> </div>
                            <div class="menu__title">
                                Roles
                                <div class="side-menu__sub-icon "> <i data-lucide="chevron-down"></i> </div>
                            </div>
                        </a>
                        <ul class="menu__sub-open">
                            <li>
                                <a href="<?php echo e(route('role.index')); ?>" class="menu">
                                    <div class="menu__icon"> <i data-lucide="list"></i> </div>
                                    <div class="menu__title">View Roles </div>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('role.create')); ?>" class="menu">
                                    <div class="menu__icon"> <i data-lucide="inbox"></i> </div>
                                    <div class="menu__title"> Add Role </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" class="menu">
                            <div class="menu__icon"> <i data-lucide="users"></i> </div>
                            <div class="menu__title">
                                Users
                                <div class="side-menu__sub-icon "> <i data-lucide="chevron-down"></i> </div>
                            </div>
                        </a>
                        <ul class="menu__sub">
                            <li>
                                <a href="<?php echo e(route('user.index')); ?>" class="menu">
                                    <div class="menu__icon"> <i data-lucide="list"></i> </div>
                                    <div class="menu__title"> View User </div>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('user.create')); ?>" class="menu">
                                    <div class="menu__icon"> <i data-lucide="inbox"></i> </div>
                                    <div class="menu__title"> Add User </div>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li >
                        <a href="#" class="menu">
                            <div class="menu__icon"> <i data-lucide="file-text"></i> </div>
                            <div class="menu__title">
                                Sheet
                                
                            </div>
                        </a>
                    </li>
                    
                </ul>
            </div>
        </div>
        <!-- END: Mobile Menu -->
        <!-- BEGIN: Top Bar -->
        <div class="top-bar-boxed h-[70px] md:h-[65px] z-[51] border-b border-white/[0.08] mt-12 md:mt-0 -mx-3 sm:-mx-8 md:-mx-0 px-3 md:border-b-0 relative md:fixed md:inset-x-0 md:top-0 sm:px-8 md:px-10 md:pt-10 md:bg-gradient-to-b md:from-slate-100 md:to-transparent dark:md:from-darkmode-700">
            <div class="h-full flex items-center">
                <!-- BEGIN: Logo -->
                <a href="" class="logo -intro-x hidden md:flex xl:w-[180px] block">
                    <img alt="Firm TechSol" class="logo__image w-6" src="<?php echo e(asset('images/logo.svg')); ?>">
                    <span class="logo__text text-white text-lg ml-3"> FTS</span>
                </a>
                <!-- END: Logo -->
                <!-- BEGIN: Breadcrumb -->
                <nav aria-label="breadcrumb" class="-intro-x h-[45px] mr-auto">
                    <ol class="breadcrumb breadcrumb-light">
                        <li class="breadcrumb-item"><a href="#">Application</a></li>
                        
                    </ol>
                </nav>
                <!-- END: Breadcrumb -->
                <!-- BEGIN: Search -->
                
                <!-- END: Search -->
                <!-- BEGIN: Notifications -->
                
                <!-- END: Notifications -->
                <!-- BEGIN: Account Menu -->
                <div class="intro-x dropdown w-8 h-8">
                    <div class="dropdown-toggle w-8 h-8 rounded-full overflow-hidden shadow-lg image-fit zoom-in scale-110" role="button" aria-expanded="false" data-tw-toggle="dropdown">
                        <img alt="Midone - HTML Admin Template" src="<?php echo e(asset('images/profile-5.jpg')); ?>">
                    </div>
                    <div class="dropdown-menu w-56">
                        <ul class="dropdown-content bg-primary/80 before:block before:absolute before:bg-black before:inset-0 before:rounded-md before:z-[-1] text-white">
                            <li class="p-2">
                                <?php if(auth()->guard()->check()): ?>
                                <div class="font-medium"><?php echo e(Auth::user()->name); ?></div>
                                <div class="text-xs text-white/60 mt-0.5 dark:text-slate-500"><?php echo e(Auth::user()->roles->name); ?></div>
                                <?php endif; ?>
                            </li>
                            <li>
                                <hr class="dropdown-divider border-white/[0.08]">
                            </li>
                            <li>
                                <a href="<?php echo e(route('profile')); ?>" class="dropdown-item hover:bg-white/5"> <i data-lucide="user" class="w-4 h-4 mr-2"></i> Profile </a>
                            </li>
                            
                            
                            <li>
                                <a href="" class="dropdown-item hover:bg-white/5"> <i data-lucide="help-circle" class="w-4 h-4 mr-2"></i> Help </a>
                            </li>
                            <li>
                                <hr class="dropdown-divider border-white/[0.08]">
                            </li>
                            <li>
                                <a class="dropdown-item hover:bg-white/5" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i data-lucide="toggle-right" class="w-4 h-4 mr-2"></i>  <?php echo e(__('Logout')); ?></a>
                                
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- END: Account Menu -->
            </div>
        </div>
        <!-- END: Top Bar -->
<?php /**PATH C:\laragon\www\FtsCrm\resources\views/layouts/Component/Header.blade.php ENDPATH**/ ?>