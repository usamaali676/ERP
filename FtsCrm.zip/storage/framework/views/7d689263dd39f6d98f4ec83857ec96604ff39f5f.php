<meta charset="utf-8">
<link href="<?php echo e(asset('images/logo1.svg')); ?>" rel="shortcut icon">
<meta name="viewport" content="width=device-width, initial-scale=1">


<meta name="author" content="LEFT4CODE">
<title>Dashboard - Firm Tech Services - CRM</title>
<!-- BEGIN: CSS Assets-->
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">

<?php /**PATH D:\xampp\htdocs\FtsCrm\resources\views/layouts/Component/head.blade.php ENDPATH**/ ?>