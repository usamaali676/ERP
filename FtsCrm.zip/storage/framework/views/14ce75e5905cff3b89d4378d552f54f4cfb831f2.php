<script src="https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/markerclusterer.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=["your-google-map-api"]&libraries=places"></script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/ckeditor-classic.js')); ?>"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/d3/4.5.0/d3.min.js'></script>
<script src="<?php echo e(asset('js/datatables.min.js')); ?>"></script>
<!--<script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>-->
<script src="<?php echo e(asset('js/script.js')); ?>"></script>


<script>
    $(document).ready(function () {
    $('#example').DataTable();
});
</script>
<?php /**PATH C:\laragon\www\FtsCrm\resources\views/layouts/Component/footer.blade.php ENDPATH**/ ?>