<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content -->
    <div class="content content--top-nav">
        <div class="intro-y flex items-center mt-8">
            <h2 class="text-lg font-medium mr-auto">
                Detail Designation
            </h2>
        </div>
        <!-- BEGIN: Input -->
        <div class="intro-y box mt-4">

            <div id="input" class="p-5">
                <div class="preview">
                    <b>Name:</b> <?php echo e($desig->name); ?>

                </div>
            </div>
            <!-- END: Input -->
        </div>
        <!-- END: Content -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\FtsCrm\resources\views/designation/detail.blade.php ENDPATH**/ ?>